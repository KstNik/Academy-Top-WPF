﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Calculator {
    public partial class MainWindow : Window {
        private string currentNumber = string.Empty;
        private string previousExpression = string.Empty;

        public MainWindow() {
            InitializeComponent();
        }

        private void Digit_Click(object sender, RoutedEventArgs e) {
            Button button = (Button)sender;
            // Проверка, что не вводится число, начинающееся с нуля без десятичной точки
            if (!(currentNumber == "0" && button.Tag.ToString() != "0")) {
                currentNumber += button.Tag.ToString();
                UpdateCurrentTextBox();
            }
        }

        private void Dot_Click(object sender, RoutedEventArgs e) {
            if (!currentNumber.Contains(".")) {
                currentNumber += ".";
                UpdateCurrentTextBox();
            }
        }

        private void Operation_Click(object sender, RoutedEventArgs e) {
            Button button = (Button)sender;
            if (!string.IsNullOrEmpty(currentNumber)) {
                previousExpression = $"{previousExpression} {currentNumber} {button.Tag}";
                currentNumber = string.Empty;
                UpdateHistoryTextBox();
            }
        }

        private void Equals_Click(object sender, RoutedEventArgs e) {
            if (!string.IsNullOrEmpty(currentNumber)) {
                previousExpression = $"{previousExpression} {currentNumber}";
                try {
                    var result = EvaluateExpression(previousExpression);
                    currentNumber = result.ToString();
                    previousExpression = string.Empty;
                    UpdateCurrentTextBox();
                    UpdateHistoryTextBox();
                }
                catch (Exception ex) {
                    MessageBox.Show($"Error: {ex.Message}");
                    ClearAll();
                }
            }
        }

        private void CE_Click(object sender, RoutedEventArgs e) {
            currentNumber = string.Empty;
            UpdateCurrentTextBox();
        }

        private void C_Click(object sender, RoutedEventArgs e) {
            ClearAll();
        }

        private void Backspace_Click(object sender, RoutedEventArgs e) {
            if (!string.IsNullOrEmpty(currentNumber)) {
                currentNumber = currentNumber.Substring(0, currentNumber.Length - 1);
                UpdateCurrentTextBox();
            }
        }

        private void UpdateCurrentTextBox() {
            currentTextBox.Text = currentNumber;
        }

        private void UpdateHistoryTextBox() {
            historyTextBox.Text = previousExpression;
        }

        private void ClearAll() {
            currentNumber = string.Empty;
            previousExpression = string.Empty;
            UpdateCurrentTextBox();
            UpdateHistoryTextBox();
        }

        private double EvaluateExpression(string expression) {
            try {
                return Convert.ToDouble(new System.Data.DataTable().Compute(expression, ""));
            }
            catch (Exception ex) {
                throw new Exception($"Invalid expression: {ex.Message}");
            }
        }
    }
}

/*Задание 2. Необходимо разработать приложение «Калькулятор». В верхней части приложения необходимо использовать два 
поля для ввода текста. Первое используется для отображения предыдущих операций, а второе – для ввода текущего числа. 
Оба поля должны запрещать редактировать своё содержимое посредством клавиатурного ввода. Данные поля будут 
заполняться автоматически при нажатии на соответствующие кнопки, расположенные ниже.
Кнопки «0» - «9» добавляют соответствующую цифру в конец текущего числа. При этом должны выполняться проверки, 
не допускающие неправильного ввода. Например, нельзя вводить числа, начинающиеся с ноля, после которого 
нет десятичной точки.
Кнопка «.» добавляет (если это возможно) десятичную точку в текущее число.
Кнопки «/», «*», «+», «-» выполняют соответствующую операцию над результатом предыдущей операции и текущим числом.
Кнопка «=» вычисляет выражение и выводит результат.
Кнопка «CE» очищает текущее число.
Кнопка «C» очищает текущее число и предыдущее выражение.
Кнопка «<» очищает последний введённый символ в текущем числе.*/