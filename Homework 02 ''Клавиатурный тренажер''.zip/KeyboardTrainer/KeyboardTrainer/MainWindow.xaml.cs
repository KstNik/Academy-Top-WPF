﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

namespace KeyboardTrainer {
    public partial class MainWindow : Window {
        int tempTimer = 0;
        int fails = 0;
        Random randChar = new Random();
        string baseString = "QWERTYUIOPASDFGHJKLZXCVBNM~!@#$%^&*()_+{}|:\"<>?1234567890[],./\\`-=;'qwertyuiopasdfghjklzxcvbnm";
        bool flagCapsLock = true;
        bool flagBackspace = true;
        bool mesStop = true;
        DispatcherTimer timer = null;
        public MainWindow() {
            InitializeComponent();
            timer = new DispatcherTimer();
            timer.Tick += Timer_Tick;
            timer.Interval = new TimeSpan(0, 0, 0, 0, 1000);
        }
        private void CapitalLetters() {
            char startChar = 'A';
            for (int i = 0; i < 26; i++) {
                char currentChar = (char)(startChar + i);
                UpdateButtonContent(currentChar.ToString(), flagCapsLock ? currentChar.ToString() : currentChar.ToString().ToLower());
            }
        }
        private void LowerLetters() {
            char startChar = 'a';
            for (int i = 0; i < 26; i++) {
                char currentChar = (char)(startChar + i);
                UpdateButtonContent(currentChar.ToString(), flagCapsLock ? currentChar.ToString() : currentChar.ToString().ToUpper());
            }
        }
        private void CapitalSymbol() {
            char startChar = '~';
            for (int i = 0; i < 15; i++) {
                char currentChar = (char)(startChar + i);
                UpdateButtonContent($"Oem{i + 3}", currentChar.ToString());
            }
        }
        private void LowerSymbol() {
            char startChar = '`';
            for (int i = 0; i < 15; i++) {
                char currentChar = (char)(startChar + i);
                UpdateButtonContent($"Oem{i + 3}", currentChar.ToString());
            }
        }
        private void UpdateButtonContent(string buttonName, string buttonText) {
            Button button = FindName(buttonName) as Button;
            if (button != null)
                button.Content = buttonText;
        }
        private void MainWindow_KeyDown(object sender, KeyEventArgs e) {
            foreach (UIElement element in (Content as Grid)?.Children) {
                if (element is Grid grid) {
                    foreach (var item in grid.Children.OfType<Button>().Where(button => button.Name == e.Key.ToString())) {
                        item.Opacity = 0.5;
                        if (e.Key.ToString() == "LeftShift" || e.Key.ToString() == "RightShift") {
                            CapitalSymbol();
                            if (flagCapsLock)
                                CapitalLetters();
                            else
                                LowerLetters();
                        }
                        else if (e.Key.ToString() == "Capital") {
                            flagCapsLock = !flagCapsLock;
                            if (flagCapsLock)
                                CapitalLetters();
                            else
                                LowerLetters();
                        }
                        else if (e.Key.ToString() == "Back")
                            flagBackspace = false;
                        else
                            flagBackspace = true;
                    }
                }
            }
        }
        private void Form_PreviewKeyUp(object sender, KeyEventArgs e) {
            lineUser.Focus();
            foreach (UIElement element in (Content as Grid)?.Children) {
                if (element is Grid grid) {
                    foreach (var item in grid.Children.OfType<Button>().Where(button => button.Name == e.Key.ToString())) {
                        item.Opacity = 1;
                        if (e.Key.ToString() == "LeftShift" || e.Key.ToString() == "RightShift") {
                            LowerSymbol();
                            if (!flagCapsLock)
                                CapitalLetters();
                            else
                                LowerLetters();
                        }
                    }
                }
            }
            if (!mesStop) {
                MessageBox.Show($"Задание завершено!\nКоличество символов {linePrograms.Text.Length}.\nКоличество ошибок {fails}.\nДля завершения задания нажмите Stop.",
                    "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                mesStop = true;
            }
        }
        private void SliderDifficulty_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e) {
            Difficulty.Content = (int)SliderDifficulty.Value;
        }
        private void Start_Click(object sender, RoutedEventArgs e) {
            Start.IsEnabled = false;
            SliderDifficulty.IsEnabled = false;
            CaseSensitive.IsEnabled = false;
            Stop.IsEnabled = true;
            tempTimer = 0;
            timer.Start();
            CollectString((int)SliderDifficulty.Value, baseString, !CaseSensitive.IsChecked.Value);
            lineUser.IsReadOnly = false;
            lineUser.IsEnabled = true;
            lineUser.Focus();
        }
        private void Timer_Tick(object sender, EventArgs e) {
            tempTimer++;
            Speed();
        }
        private void CollectString(int countChar, string baseString, bool flagSensitive) {
            string chars = "";
            int sensitive = flagSensitive ? 47 : 0;
            for (int i = 0; i < countChar; i++)
                chars += baseString[randChar.Next(sensitive, baseString.Length)];
            chars += " ";
            int countString = flagSensitive ? 75 : 70;
            for (int i = 0; i < countString; i++)
                linePrograms.Text += chars[randChar.Next(0, chars.Length)];
        }
        private void Stop_Click(object sender, RoutedEventArgs e) {
            Start.IsEnabled = true;
            SliderDifficulty.IsEnabled = true;
            CaseSensitive.IsEnabled = true;
            Stop.IsEnabled = false;
            lineUser.Text = "";
            linePrograms.Text = "";
            Fails.Content = 0;
            SpeedChar.Content = 0;
            lineUser.IsReadOnly = true;
            lineUser.IsEnabled = false;
            timer.Stop();
            tempTimer = 0;
            fails = 0;
        }
        private void lineUser_TextChanged(object sender, TextChangedEventArgs e) {
            string str = linePrograms.Text.Substring(0, lineUser.Text.Length);
            if (lineUser.Text.Equals(str)) {
                if (flagBackspace)
                    Speed();
                lineUser.Foreground = new SolidColorBrush(Colors.Black);
            }
            else {
                if (flagBackspace)
                    fails++;
                lineUser.Foreground = new SolidColorBrush(Colors.Red);
                Fails.Content = fails;
            }
            if (lineUser.Text.Length == linePrograms.Text.Length) {
                timer.Stop();
                Speed();
                lineUser.IsReadOnly = true;
                mesStop = false;
            }
        }
        private void CaseSensitive_Checked(object sender, RoutedEventArgs e) {
            SliderDifficulty.Maximum = 94;
        }
        private void CaseSensitive_Unchecked(object sender, RoutedEventArgs e) {
            SliderDifficulty.Maximum = 47;
        }
        void Speed() {
            SpeedChar.Content = Math.Round(((double)lineUser.Text.Length / tempTimer) * 60).ToString();
        }
    }
}

/*Задание. Необходимо разработать приложение «Клавиатурный тренажёр».
Главное окно приложения должно отображать клавиатуру с не интерактивными клавишами, которые необходимо для 
того, чтобы помогать пользователю ориентироваться на клавиатуре, не смотря на неё. При этом, при нажатии 
на каждую из клавиш, она должна подсвечиваться на экране. После запуска тренировочной сессии пользователю 
должна отобразиться произвольно сгенерированная строка для ввода, которая учитывает выбранный уровень 
сложности.
В верхней части окна должна отображаться статистическая информация: скорость набора корректного текста и 
количество допущенных ошибок. Также в верхней части окна должны располагаться элементы управления, 
позволяющие настроить сложность генерируемой строки для ввода. При помощи «ползунка» пользователь может 
выбрать количество символов, которые должны использоваться для генерируемой строки. При этом можно указать 
необходимо ли генерировать строку с учётом регистра символов. В качестве используемых символов могут быть 
все символы.
После нажатия на кнопку «Start» должна сгенерироваться строка символов с учётом заданных пользователем 
настроек. После этого нажимаемые пользователем клавиши должны учитываться и отображаться в виде введённых 
правильно символов либо в виде ошибок.
При нажатии на клавиши Shift и Caps Lock, клавиатура в приложении должна менять отображаемые символы, с 
учётом реально вводимых.
Также необходимо предусмотреть выключение тех элементов управления, которые не могут использоваться в 
текущем состоянии приложения. Например, нельзя нажимать кнопку «Stop», если пользователь перед этим не 
нажал кнопку «Start».*/