﻿using System; // основные типы и классы .NET
using System.Collections.ObjectModel; // коллекции для привязки данных
using System.Linq; // LINQ для работы с коллекциями
using System.Windows; // базовые классы WPF
using System.Windows.Controls; // элементы управления WPF
using System.Numerics; /* работа с комплексными числами, добавление ссылки щелчок правой кнопкой по проекту 
    в обозревателе решений -> пункт меню «Добавить» -> подпункт «Ссылка» -> в открывшемся окне выбрать 
    «System.Numerics» -> кнопка «Ok» */
using MathNet.Numerics; /* математические функции, установка: пункт меню «Tools» («Проект») ->
    подпункт «NuGet Package Manager» («Управление пакетами NuGe»t) -> окно «Обзор» ->
    найти и выбрать MathNet.Numerics -> кнопка «Установить» */
using MathNet.Numerics.LinearAlgebra; // линейная алгебра
using MathNet.Numerics.LinearAlgebra.Double; // реализация линейной алгебры для double
using MathNet.Numerics.LinearAlgebra.Factorization; // спектральное разложение матриц

namespace MatrixCalculator {
    public partial class MainWindow : System.Windows.Window {
        ObservableCollection<double[]> matrixData; // коллекция для хранения данных матрицы (для привязки к DataGrid)
        private double[,] storedMatrix; // временное хранилище матрицы для операций
        // флаги режимов работы
        private bool isOperationMode = false; // режим выполнения операции (сложение/вычитание)
        private bool isMultiplicationMode = false; // режим умножения матриц
        private bool isAdditionOperation = false; // тип операции (true - сложение, false - вычитание)

        public MainWindow() { // конструктор главного окна
            InitializeComponent();
            MatrixDataGrid.CurrentCellChanged += MatrixDataGrid_CurrentCellChanged; // подписка на событие изменения текущей ячейки
            UpdateButtonStates(); // оОбновление состояния кнопок
        }
        // Обработчик завершения редактирования ячейки
        private void MatrixDataGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e) {
            if (e.EditAction == DataGridEditAction.Commit) { // если редактирование подтверждено
                var textBox = e.EditingElement as TextBox; // получение TextBox применяемого для редактирования
                if (textBox != null) { // проверка, что элемент редактирования TextBox
                    // получение введённого пользователем текста
                    string input = textBox.Text;
                    double result;
                    if (TryParseIrrationalNumber(input, out result)) { // парсинг специальных значений (π, e, sqrt и т.д.)
                        // распознавание успешно – замена текста на числовое значение в инвариантном формате (разделитель – точка)
                        textBox.Text = result.ToString(System.Globalization.CultureInfo.InvariantCulture);
                    }
                }
            }
        }
        // Копирование матрицы в буфер обмена
        private void CopyMatrix_Click(object sender, RoutedEventArgs e) {
            var matrix = GetMatrixFromDataGrid();  // получение матрицы из DataGrid
            if (matrix.GetLength(0) == 0 || matrix.GetLength(1) == 0) return; // проверка, что матрица не пустая
            var sb = new System.Text.StringBuilder(); // создание StringBuilder для эффективного построения строки
            // формирование текстового представления матрицы
            for (int i = 0; i < matrix.GetLength(0); i++) { // преобразование числа в строку (разделитель - точка)
                for (int j = 0; j < matrix.GetLength(1); j++) { // замена точки на запятые для корректного отображения
                    sb.Append(matrix[i, j].ToString(System.Globalization.CultureInfo.InvariantCulture).Replace(".", ","));
                    if (j < matrix.GetLength(1) - 1) // добавление пробелов между элементами строки, кроме последнего
                        sb.Append(" ");
                }
                if (i < matrix.GetLength(0) - 1) // добавление перевода строки после каждой строки матрицы, кроме последней
                    sb.AppendLine();
            }
            Clipboard.SetText(sb.ToString()); // копирование сформированной строки в буфер обмена
        }
        // Вставка матрицы из буфера обмена
        private void PasteMatrix_Click(object sender, RoutedEventArgs e) {
            try {
                if (!Clipboard.ContainsText()) return; // проверка наличия текста в буфере обмена
                string clipboardText = Clipboard.GetText(); // получение текста из буфера
                // разбивка текста на строки и удаление пустых строк
                string[] rows = clipboardText.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
                if (rows.Length == 0) return;
                // разбивка 1-ой строки на элементы (по пробелам или табуляции)
                string[] firstRow = rows[0].Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                // определение количества столбцов и строк
                int colCount = firstRow.Length;
                int rowCount = rows.Length;
                double[,] newMatrix = new double[rowCount, colCount]; // создание новой матрицы соответствующего размера
                // парсинг значений из буфера обмена
                for (int i = 0; i < rowCount; i++) { // разбивка текущей строки на элементы
                    string[] values = rows[i].Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                    if (values.Length != colCount) { // проверка соответствия количества элементов в текущей строке количеству в первой
                        // сообщение об ошибке "Все строки должны иметь одинаковое количество элементов."
                        MessageBox.Show("All rows must have the same number of elements.");
                        return;
                    }
                    // обработка каждого элемента строки
                    for (int j = 0; j < colCount; j++) { // замена запятых на точки для корректного парсинга
                        string value = values[j].Replace(",", ".");
                        // преобразование в число
                        if (!double.TryParse(value, System.Globalization.NumberStyles.Any,
                            System.Globalization.CultureInfo.InvariantCulture, out newMatrix[i, j])) {
                            // в случае ошибки – сообщение с позицией ошибки
                            MessageBox.Show($"Invalid number format at row {i + 1}, column {j + 1}");
                            return;
                        }
                    }
                }
                // обновление размеров и отображение матрицы
                txtRows.Text = rowCount.ToString();
                txtColumns.Text = colCount.ToString();
                DisplayMatrixInDataGrid(newMatrix);
            }
            catch (Exception ex) { // обработка непредвиденных ошибок
                MessageBox.Show($"Error pasting matrix: {ex.Message}");
            }
        }
        // Парсинг специальных значений (π, e, sqrt, cbrt и математических выражений) возвращается true, если преобразование успешно, и результат
        private bool TryParseIrrationalNumber(string input, out double result) {
            result = 0; // инициализация результата значением по умолчанию
            if (string.IsNullOrWhiteSpace(input)) // проверка на пустую строку или строку из пробелов
                return false;
            input = input.ToLower().Replace(" ", "").Replace(",", "."); // приведение к нижнему регистру, удаление пробелов, замена запятых на точки
            // сначала пробуется стандартный парсинг
            if (double.TryParse(input, System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture, out result)) // применение InvariantCulture, чтобы избежать проблем с разделителями в разных культурах
                return true;
            // обработка констант
            if (input == "pi" || input == "π") {
                result = Math.PI;
                return true;
            }
            if (input == "e") {
                result = Math.E;
                return true;
            }
            // обработка функций и выражений
            try {
                if (input.StartsWith("sqrt(") && input.EndsWith(")")) { // проверка на квадратный корень: sqrt(число)
                    // извлечение аргумента из скобок (подстрока между "sqrt(" и ")")
                    string arg = input.Substring(5, input.Length - 6);
                    double argValue;
                    if (TryParseIrrationalNumber(arg, out argValue)) { // рекурсивный парсинг аргумента
                        result = Math.Sqrt(argValue); // вычисление квадратного корня
                        return true;
                    }
                }
                else if (input.StartsWith("cbrt(") && input.EndsWith(")")) { // порядок действий аналогичен
                    string arg = input.Substring(5, input.Length - 6);
                    double argValue;
                    if (TryParseIrrationalNumber(arg, out argValue)) {
                        result = Math.Pow(argValue, 1.0 / 3.0);
                        return true;
                    }
                }
                else if (input.Contains("/")) { // обработка деления: a / b
                    string[] parts = input.Split('/');
                    if (parts.Length == 2) { // проверка, что строка разделилась на 2 части (числитель и знаменатель)
                        double numerator, denominator;
                        // рекурсивный парсинг обеих частей
                        if (TryParseIrrationalNumber(parts[0], out numerator) &&
                            TryParseIrrationalNumber(parts[1], out denominator) &&
                            denominator != 0) { // проверка деления на 0
                            result = numerator / denominator;
                            return true;
                        }
                    }
                }
                else if (input.Contains("*")) { // порядок действий аналогичен
                    string[] parts = input.Split('*');
                    if (parts.Length == 2) {
                        double left, right;
                        if (TryParseIrrationalNumber(parts[0], out left) &&
                            TryParseIrrationalNumber(parts[1], out right)) {
                            result = left * right;
                            return true;
                        }
                    }
                }
                else if (input.Contains("+")) { // порядок действий аналогичен
                    string[] parts = input.Split('+');
                    if (parts.Length == 2) {
                        double left, right;
                        if (TryParseIrrationalNumber(parts[0], out left) &&
                            TryParseIrrationalNumber(parts[1], out right)) {
                            result = left + right;
                            return true;
                        }
                    }
                }
                else if (input.Contains("-") && input.IndexOf('-') > 0) { // порядок действий аналогичен
                    string[] parts = input.Split('-'); // проверка что 1-ое число положительное
                    if (parts.Length == 2) {
                        double left, right;
                        if (TryParseIrrationalNumber(parts[0], out left) &&
                            TryParseIrrationalNumber(parts[1], out right)) {
                            result = left - right;
                            return true;
                        }
                    }
                }
            }
            catch {
                return false; // произошла любая ошибка
            }
            return false; // ни один из вариантов не подошел
        }
        // Обработчик изменения текущей ячейки
        private void MatrixDataGrid_CurrentCellChanged(object sender, EventArgs e) {
            UpdateMatrixCalculations(); // обновление расчётов матрицы
            UpdateButtonStates(); // обновление состояний кнопок интерфейса
        }
        // Обновление состояния кнопок в зависимости от свойств матрицы
        private void UpdateButtonStates() {
            var matrix = GetMatrixFromDataGrid(); // получение текущей матрицы из DataGrid
            // определение размеров матрицы, количество
            int rows = matrix.GetLength(0); // строк
            int columns = matrix.GetLength(1); // столбцов
            bool isSquare = rows == columns; // ИСТИНА – для квадратной матрицы
            btnTranspose.IsEnabled = rows > 0 && columns > 0; // транспонирование доступно для любой непустой матрицы
            // включение кнопок для квадратной матрицы
            btnInverse.IsEnabled = isSquare && rows > 0;
            btnPower.IsEnabled = isSquare && rows > 0;
            btnExp.IsEnabled = isSquare && rows > 0;
            btnLog.IsEnabled = isSquare && rows > 0;
            btnSin.IsEnabled = isSquare && rows > 0;
            btnCos.IsEnabled = isSquare && rows > 0;
            btnTan.IsEnabled = isSquare && rows > 0;
            btnSinh.IsEnabled = isSquare && rows > 0;
            btnCosh.IsEnabled = isSquare && rows > 0;
            btnTanh.IsEnabled = isSquare && rows > 0;
            btnRoot.IsEnabled = isSquare && rows > 0;
            btnBasePower.IsEnabled = isSquare && rows > 0;
            btnLogBase.IsEnabled = isSquare && rows > 0;
        }
        // Генерация новой матрицы по заданным размерам
        private void GenerateMatrix_Click(object sender, RoutedEventArgs e) {
            // преобразование текстовых значений строк и столбцов в числа
            if (int.TryParse(txtRows.Text, out int rows) && int.TryParse(txtColumns.Text, out int columns)) {
                MatrixDataGrid.Columns.Clear(); // удаление всех столбцов из DataGrid
                matrixData = new ObservableCollection<double[]>(); // инициализация новой коллекции для хранения матрицы
                for (int i = 0; i < columns; i++) { // добавление столбцов в DataGrid
                    MatrixDataGrid.Columns.Add(new DataGridTextColumn {
                        Header = $"C{i + 1}", // заголовок столбца (C1, C2, C3, ...)
                        Binding = new System.Windows.Data.Binding($"[{i}]") // привязка к элементу массива
                    });
                }
                // заполнение 0
                for (int i = 0; i < rows; i++) { // добавление строки с массивами 0 соответствующего размера 
                    matrixData.Add(new double[columns]); // создание новой строки матрицы
                }
                MatrixDataGrid.ItemsSource = matrixData; // установка созданной коллекции как источника данных для DataGrid
                UpdateMatrixCalculations(); // пересчёт параметров матрицы (детерминант, след)
                UpdateButtonStates(); // обновление состояния кнопок (активные/неактивные)
            }
            else { // некорректные значения размеров матрицы
                // сообщение об ошибке "Пожалуйста, введите допустимые значения строк и столбцов."
                MessageBox.Show("Please enter valid row and column values.");
            }
        }
        // Создание двумерного массива, содержащего значения матрицы из DataGrid
        private double[,] GetMatrixFromDataGrid() {
            if (MatrixDataGrid.Items.Count == 0 || MatrixDataGrid.Columns.Count == 0) // проверка данных в DataGrid
                return new double[0, 0]; // возвращение пустой матрицы, если данных нет
            // определение размеров матрицы, количество
            int rows = MatrixDataGrid.Items.Count; // строк
            int columns = MatrixDataGrid.Columns.Count; // столбцов
            double[,] matrix = new double[rows, columns]; // создание двумерного массива соответствующего размера
            // заполнение массива значениями из DataGrid
            for (int i = 0; i < rows; i++) { // перебор строк
                for (int j = 0; j < columns; j++) { // перебор столбцов
                    if (MatrixDataGrid.Items[i] is double[] row) { // проверка, что элемент является массивом double[] (каждый массив double[] представляет одну строку матрицы)
                        matrix[i, j] = row[j]; // копирование значения из соответствующей ячейки
                    }
                }
            }
            return matrix;
        }
        // Обновление вычислений определителя и следа матрицы
        private void UpdateMatrixCalculations() {
            var matrix = GetMatrixFromDataGrid(); // получение текущей матрицы из DataGrid
            // определение размеров матрицы, количество
            int rows = matrix.GetLength(0); // строк
            int columns = matrix.GetLength(1); // столбцов
            if (rows == columns) { // для квадратных матриц вычисляются определитель и след, остальные поля доступны для ввода
                txtDeterminant.Text = CalculateDeterminant(matrix).ToString();
                txtTrace.Text = CalculateTrace(matrix).ToString();
                txtExponent.IsEnabled = true;
                txtRootExponent.IsEnabled = true;
                txtBaseDegree.IsEnabled = true;
                txtLogarithm.IsEnabled = true;
            }
            else { // для неквадратных матриц выводятся значения N/A, остальные поля – блокируются
                txtDeterminant.Text = "N/A";
                txtTrace.Text = "N/A";
                txtExponent.IsEnabled = false;
                txtRootExponent.IsEnabled = false;
                txtBaseDegree.IsEnabled = false;
                txtLogarithm.IsEnabled = false;
            }
        }
        // Вычисление определителя матрицы (рекурсивный метод)
        private double CalculateDeterminant(double[,] matrix) {
            int n = matrix.GetLength(0); // размер матрицы
            if (n == 1) return matrix[0, 0]; // определитель 1x1 – сам элемент
            if (n == 2) return matrix[0, 0] * matrix[1, 1] - matrix[0, 1] * matrix[1, 0]; // формула для 2x2
            /* рекурсивные случаи для матриц размером 3x3 и больше,
            пример для 3x3:
            | a b c |
            | d e f | = a(ei - fh) - b(di - fg) + c(dh - eg)
            | g h i |
            пример для 4x4:
            | a b c d |       | f g h |       | e g h |       | e f h |       | e f g |
            | e f g h | = a * | j k l | - b * | i k l | + c * | i j l | - d * | i j k | = 
            | i j k l |       | n o p |       | m o p |       | m n p |       | m n o |
            | m n o p |
            = a[f(kp-lo)-g(jp-ln)+h(jo-kn)] - b[e(kp-lo)-g(ip-lm)+h(io-km)] + c[e(jp-ln)-f(ip-lm)+h(in-jm)] - d[e(jo-kn)-f(io-km)+g(in-jm)] */
            double determinant = 0;
            for (int p = 0; p < n; p++) { // разложение по первой строке (можно выбрать любую строку)
                double[,] minor = GetMinor(matrix, 0, p); // получение минора матрицы (подматрица без 0-й строки и p-го столбца)
                // рекурсивное вычисление определителя минора, добавление к определителю с учётом знака (-1)^(i + j)
                determinant += matrix[0, p] * CalculateDeterminant(minor) * ((p % 2 == 0) ? 1 : -1);
            }
            return determinant;
        }
        // Получение минора матрицы (удаление строки и столбца)
        private double[,] GetMinor(double[,] matrix, int row, int column) {
            int n = matrix.GetLength(0); // размер матрицы
            double[,] minor = new double[n - 1, n - 1]; // создание новой матрицы для минора (размером n-1 x n-1)
            int mRow = 0, mCol = 0; // индексы для заполнения минора
            for (int i = 0; i < n; i++) { // проход по всем строкам исходной матрицы
                if (i == row) continue; // пропуск исключаемой строки
                mCol = 0; // сбрасм индекса столбца для каждой новой строки
                for (int j = 0; j < n; j++) { // проход по всем столбцам исходной матрицы
                    if (j == column) continue; // пропуск исключаемого столбца
                    minor[mRow, mCol] = matrix[i, j]; // копирование элемента в минор
                    mCol++; // переход к следующему столбцу минора
                }
                mRow++; // переход к следующей строке минора
            }
            return minor;
        }
        // Вычисление следа матрицы (сумма диагональных элементов)
        private double CalculateTrace(double[,] matrix) {
            int n = matrix.GetLength(0); // размер матрицы
            // пример для 3x3:
            // | a b c |
            // | d e f | = a + e + i
            // | g h i |
            double trace = 0;
            for (int i = 0; i < n; i++) {
                trace += matrix[i, i]; // сумма элементов, у которых номер строки равен номеру столбца
            }
            return trace;
        }
        // Обработчик нажатия кнопок сложения/вычитания
        private void AddOrSubtractMatrices_Click(object sender, RoutedEventArgs e) {
            // проверка, что отправитель – кнопка и содержит корректный Tag
            if (sender is Button button && bool.TryParse(button.Tag?.ToString(), out bool isAddition)) {
                storedMatrix = GetMatrixFromDataGrid(); // сохранение текущей матрицы как первого операнда
                isOperationMode = true; // общий флаг режима операций
                isMultiplicationMode = false; // указание – не является умножением
                isAdditionOperation = isAddition; // сохранение типа операции (true – сложение, false – вычитание)
                // запрет
                txtRows.IsEnabled = false; // изменения количества строк
                txtColumns.IsEnabled = false; // ... столбцов
                btnGenerateMatrix.IsEnabled = false; // генерации новой матрицы
                FillMatrixWithZeros(); // заполнение DataGrid нулями для второй матрицы
            }
        }
        // Заполнение матрицы нулями
        private void FillMatrixWithZeros() {
            if (matrixData != null) { // проверка, что коллекция matrixData инициализирована
                foreach (var row in matrixData) { // проход по всем строкам матрицы
                    for (int i = 0; i < row.Length; i++) { // проход по всем элементам строки
                        row[i] = 0;
                    }
                }
                MatrixDataGrid.Items.Refresh(); // принудительное обновление отображения DataGrid
            }
        }
        // Обработчик нажатия кнопки умножения
        private void MultiplyMatrices_Click(object sender, RoutedEventArgs e) {
            storedMatrix = GetMatrixFromDataGrid(); // сохранение текущей матрицы как первого множителя
            isMultiplicationMode = true; // указание – операция умножения
            isOperationMode = false; // отключение флага обычных операций (сложение/вычитание)
            txtRows.Text = storedMatrix.GetLength(1).ToString(); // количество строк второй матрицы равно количеству столбцов первой
            txtRows.IsEnabled = false; // блокировка редактирования количества строк
            txtColumns.Clear(); // очистка количества столбцов для ввода нового значения
            MatrixDataGrid.ItemsSource = null; // очистка текущих данных
            MatrixDataGrid.Columns.Clear(); // удаление всех столбцов
        }
        // Обработчик нажатия кнопки "=" (выполнение операции)
        private void Equal_Click(object sender, RoutedEventArgs e) {
            if (storedMatrix == null) return; // проверка, что есть сохранённая матрица для операций
            var currentMatrix = GetMatrixFromDataGrid(); // получение текущей матрицы из DataGrid (второй операнд)
            if (isMultiplicationMode) { // выполнение операции в зависимости от активного режима
                if (storedMatrix.GetLength(1) != currentMatrix.GetLength(0)) { // валидация
                    // сообщение об ошибке: "Число столбцов первой матрицы должно равняться числу строк второй матрицы."
                    MessageBox.Show("Number of columns in the first matrix must equal number of rows in the second matrix.");
                    return;
                }
                var resultMatrix = MultiplyMatrices(storedMatrix, currentMatrix); // выполнение умножения матриц
                DisplayMatrixInDataGrid(resultMatrix); // отображение результата
            }
            else if (isOperationMode) {
                if (storedMatrix.GetLength(0) != currentMatrix.GetLength(0) ||
                    storedMatrix.GetLength(1) != currentMatrix.GetLength(1)) { // валидация
                    // сообщение об ошибке: "Матрицы должны быть одного размера."
                    MessageBox.Show("Matrix sizes must be the same.");
                    return;
                }
                var resultMatrix = MatrixAddSubtract(storedMatrix, currentMatrix, isAdditionOperation); // выполнение сложения или вычитания
                DisplayMatrixInDataGrid(resultMatrix); // отображение результата
            }
            ResetUIAfterOperation(); // сбрас состояния интерфейса после операции
        }
        // Сброс интерфейса после выполнения операции
        private void ResetUIAfterOperation() {
            // разблокировка элементов управления создающих матрицу
            txtRows.IsEnabled = true;
            txtColumns.IsEnabled = true;
            btnGenerateMatrix.IsEnabled = true;
            // сброс состояние операций
            storedMatrix = null; // очистка сохранённой матрицы
            isOperationMode = false; // выход из режима операций
            isMultiplicationMode = false; // сброс флага умножения
        }
        // Отображение матрицы в DataGrid
        private void DisplayMatrixInDataGrid(double[,] matrix) {
            // получение размеров матрицы
            int rows = matrix.GetLength(0);
            int columns = matrix.GetLength(1);
            // очистка предыдущих данных
            MatrixDataGrid.Columns.Clear();
            matrixData = new ObservableCollection<double[]>();
            for (int i = 0; i < columns; i++) { // создание столбцов DataGrid
                MatrixDataGrid.Columns.Add(new DataGridTextColumn {
                    Header = $"C{i + 1}", // нумерация столбцов с 1 (C1, C2, C3, ...)
                    Binding = new System.Windows.Data.Binding($"[{i}]") // привязка к элементу массива
                });
            }
            for (int i = 0; i < rows; i++) { // заполнение данными из матрицы
                var row = new double[columns];
                for (int j = 0; j < columns; j++) {
                    row[j] = matrix[i, j]; // копирование значений в строку
                }
                matrixData.Add(row); // добавление строки в коллекцию
            }
            MatrixDataGrid.ItemsSource = matrixData; // установка источника данных и обновление отображения
            UpdateMatrixCalculations(); // пересчёт параметров матрицы (детерминант, след)
            UpdateButtonStates(); // обновление состояния кнопок (активные/неактивные)
        }
        // Умножение матриц
        private double[,] MultiplyMatrices(double[,] matrixA, double[,] matrixB) {
            // получение размеров матриц, количество
            int rowsA = matrixA.GetLength(0); // строк 1-ой
            int colsA = matrixA.GetLength(1); // столбцов 1-ой
            int colsB = matrixB.GetLength(1); // столбцов 2-ой
            var result = new double[rowsA, colsB]; // создание результирующей матрицы
            for (int i = 0; i < rowsA; i++) { // проход по строкам 1-ой
                for (int j = 0; j < colsB; j++) { // проход по столбцам 2-ой
                    for (int k = 0; k < colsA; k++) {
                        // вычисление скалярного произведения строки i 1-ой и столбца j 2-ой матриц
                        result[i, j] += matrixA[i, k] * matrixB[k, j]; 
                    }
                }
            }
            return result;
        }
        // Обработчик кнопки "C" (очистка всего)
        private void Clear_Click(object sender, RoutedEventArgs e) {
            // очистка всех полей ввода
            txtRows.Clear();
            txtColumns.Clear();
            txtDeterminant.Clear();
            txtTrace.Clear();
            // установка значений по умолчанию
            txtExponent.Text = "2";
            txtRootExponent.Text = "2";
            txtBaseDegree.Text = "10";
            txtLogarithm.Text = "10";
            // очистка DataGrid
            MatrixDataGrid.ItemsSource = null;
            MatrixDataGrid.Columns.Clear();
            // сброс состояния
            storedMatrix = null; // очистка сохранённой матрицы
            ResetUIAfterOperation(); // сброс флагов операций
            UpdateButtonStates(); // обновление состояния кнопок
        }
        // Обработчик кнопки "CE" (очистка значений матрицы)
        private void ClearEntries_Click(object sender, RoutedEventArgs e) {
            if (matrixData != null) {
                // заполнение всех элементов 0
                foreach (var row in matrixData) {
                    for (int i = 0; i < row.Length; i++) {
                        row[i] = 0;
                    }
                }
                MatrixDataGrid.Items.Refresh(); // обновление отображения DataGrid
            }
        }
        // Обработчик кнопки транспонирования матрицы
        private void Transpose_Click(object sender, RoutedEventArgs e) {
            // получение текущей матрицы из DataGrid
            var matrix = GetMatrixFromDataGrid();
            int rows = matrix.GetLength(0);
            int columns = matrix.GetLength(1);
            var transposed = new double[columns, rows]; // создание новой матрицы с обратными размерами
            // заполнение транспонированной матрицы
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < columns; j++) {
                    transposed[j, i] = matrix[i, j]; // индексы строк и столбцов меняются местами
                }
            }
            // обновление интерфейса с новыми размерами
            txtRows.Text = columns.ToString();
            txtColumns.Text = rows.ToString();
            DisplayMatrixInDataGrid(transposed); // отображение результата
        }
        // Обработчик кнопки возведения матрицы в степень
        private void PowerMatrix_Click(object sender, RoutedEventArgs e) {
            if (!int.TryParse(txtExponent.Text, out int exponent)) { // парсинг показателя степени из текстового поля
                // сообщение об ошибке "Пожалуйста введите корректный показатель степени."
                MessageBox.Show("Please enter a valid exponent.");
                return;
            }
            var matrix = GetMatrixFromDataGrid(); // получение текущей матрицы
            if (matrix.GetLength(0) != matrix.GetLength(1)) { // проверка, что матрица квадратная
                // сообщение об ошибке "Для возведения в степень матрица должна быть квадратной."
                MessageBox.Show("Matrix must be square for exponentiation.");
                return;
            }
            var result = MatrixPower(matrix, exponent); // возведение матрицы в степень
            DisplayMatrixInDataGrid(result); // отображение результата
        }
        // Возведение матрицы в целую степень
        private double[,] MatrixPower(double[,] matrix, int power) {
            var result = (double[,])matrix.Clone(); // создание копии исходной матрицы
            for (int i = 1; i < power; i++) { // последовательное умножение матрицы на себя
                result = MultiplyMatrices(result, matrix);
            }
            return result;
        }
        // Обработчик кнопки вычисления корня матрицы
        private void RootMatrix_Click(object sender, RoutedEventArgs e) {
            if (!int.TryParse(txtRootExponent.Text, out int rootExponent) || rootExponent < 1) { // парсинг показателя корня из текстового поля
                // сообщение об ошибке "Пожалуйста введите корректную степень корня (натуральное число)."
                MessageBox.Show("Please enter a valid root exponent (natural number).");
                return;
            }
            var matrix = GetMatrixFromDataGrid(); // получение текущей матрицы
            if (matrix.GetLength(0) != matrix.GetLength(1)) { // проверка, что матрица квадратная
                // сообщение об ошибке "Для извлечения корня матрица должна быть квадратной."
                MessageBox.Show("Matrix must be square for root calculation.");
                return;
            }
            try {
                double[,] result = CalculateMatrixRootMathNet(matrix, rootExponent); // применение спектрального метода
                DisplayMatrixInDataGrid(result); // отображение результата
            }
            catch (Exception ex) { // сообщение об ошибке "Ошибка вычисления корня матрицы:"
                MessageBox.Show($"Error calculating matrix root: {ex.Message}");
            }
        }
        // Вычисление корня матрицы с использованием Math.NET (спектральное разложение)
        private double[,] CalculateMatrixRootMathNet(double[,] matrix, int root) {
            /* порядок вычисления:
            A = V * D * V^(-1) - спектральное разложение матрицы
            D = diag(λ1, λ2, λ3) - диагональная матрица собственных значений
            V = [v1 | v2 | v3] - матрица собственных векторов
            A^(1/n) = V * D^(1/n) * V^(-1), где D^(1/n) = diag(λ1^(1/n), λ2^(1/n), λ3^(1/n))
            пример для матрицы 3x3, порядок вычисления:
                | a b c |
            A = | d e f |
                | g h i |
            a) нахождение собственных значений λ1, λ2, λ3, решением характеристического уравнения det(A - λI) = 0
                |a-λ  b   c |
                | d  e-λ  f | = 0, раскрытие определителя (a-λ)[(e-λ)(i-λ) - fh] - b[d(i-λ) - fg] + c[dh - (e-λ)g] = 0,
                | g   h  i-λ|
                в итоге кубическое уравнение: -λ^3 + (a+e+i)λ^2 - (ae+ai+ei-bd-cg-fh)λ + det(A) = 0
            b) каждого λ вычисляется собственный вектор v решением (A - λI)v = 0
                (a-λ)v1 + bv2 + cv3 = 0
                dv1 + (e-λ)v2 + fv3 = 0
                gv1 + hv2 + (i-λ)v3 = 0
                пример для λ1:
                    v1 = свободная переменная (обычно 1)
                    v2 = [-(a-λ1)v1 - cv3]/b  (если b <> 0)
                    v3 = [-(a-λ1)v1 - bv2]/c  (если c <> 0)
            c) формирование матриц:
                                       | λ1 0 0 |
                D = diag(λ1, λ2, λ3) = | 0 λ2 0 | - диагональная матрица
                                       | 0 0 λ3 |
                V = [v1 v2 v3] - матрица собственных векторов
                V^(-1) - матрица обратная к V
            d) вычисление корня матрицы:
                A^(1/n) = V * D^(1/n) * V^(-1), где
                                                                | λ1^(1/n)     0        0    |
                D^(1/n) = diag(λ1^(1/n), λ2^(1/n), λ3^(1/n)) =  |     0    λ2^(1/n)     0    |
                                                                |     0        0    λ3^(1/n) |*/
            try {
                Matrix<double> mathNetMatrix = DenseMatrix.OfArray(matrix); // конвертация в матрицу Math.NET
                // вычисление спектрального разложения A = V * D * V^(-1)
                var evd = mathNetMatrix.Evd(); // выполнение собственного разложения (Eigenvalue Decomposition, EVD) матрицы
                // ВНИМАНИЕ! ЕСЛИ МАТРИЦА НЕ ДИАГОНАЛИЗИРУЕМА, Evd() ВЫБРОСИТ ИСКЛЮЧЕНИЕ
                // в этом случае необходимо применить Жорданову форму – В КОДЕ НЕ РЕАЛИЗОВАНА
                var D = evd.D; // диагональная матрица собственных значений diag(λ1, λ2, λ3)
                var V = evd.EigenVectors; // матрица собственных векторов V = [v1 v2 v3]
                // извлечение корня из диагональной матрицы, т.е. вычисление D^(1/n)
                for (int i = 0; i < D.RowCount; i++) {
                    if (root % 2 == 0 && D[i, i] < 0) { // проверка на отрицательные значения для корней чётной степени
                        // сообщение об ошибке "Невозможно вычислить чётный корень отрицательного собственного значения."
                        throw new InvalidOperationException("Cannot compute even root of negative eigenvalue.");
                    }
                    D[i, i] = Math.Pow(D[i, i], 1.0 / root);
                }
                Matrix<double> rootMatrix = V * D * V.Inverse(); // восстановление результирующей матрицы A^(1/n) = V * D^(1/root) * V^(-1)
                return rootMatrix.ToArray(); // конвертация обратно в 2D массив
            }
            catch (Exception ex) { // сообщение об ошибке "Ошибка вычисления корня матрицы:"
                MessageBox.Show($"Error calculating matrix root: {ex.Message}");
                return new double[matrix.GetLength(0), matrix.GetLength(1)];
            }
        }
        // Обработчик кнопки возведения числа в степень матрицы
        private void BasePowerMatrix_Click(object sender, RoutedEventArgs e) {
            if (!double.TryParse(txtBaseDegree.Text, out double baseDegree)) { // парсинг основания степени с проверкой
                // сообщение об ошибке "Пожалуйста, введите корректное основание степени."
                MessageBox.Show("Please enter a valid base degree.");
                return;
            }
            var matrix = GetMatrixFromDataGrid(); // получение текущей матрицы
            if (matrix.GetLength(0) != matrix.GetLength(1)) { // проверка, что матрица квадратная
                // сообщение об ошибке "Для возведения в степень матрица должна быть квадратной."
                MessageBox.Show("Matrix must be square for exponentiation.");
                return;
            }
            try {
                var result = CalculateMatrixBasePowerMathNet(matrix, baseDegree); // вычисление baseDegree^matrix через Math.NET
                DisplayMatrixInDataGrid(result); // отображение результата
            }
            catch (Exception ex) { // сообщение об ошибке "Ошибка при вычислении степени матрицы:"
                MessageBox.Show($"Error calculating matrix base power: {ex.Message}");
            }
        }
        // Вычисление матричной показательной функции с использованием Math.NET
        private double[,] CalculateMatrixBasePowerMathNet(double[,] matrix, double baseDegree) {
            /* порядок вычисления матричной экспоненты:
            B = ln(base) * A - масштабированная матрица
            B = V * D * V^(-1) - спектральное разложение
            D = diag(λ1, λ2, ..., λn) - диагональная матрица собственных значений
            V = [v1 | v2 | ... | vn] - матрица собственных векторов
            base^A = V * diag(e^λ1, e^λ2, ..., e^λn) * V^(-1) - итоговый результат */
            try {
                if (matrix.GetLength(0) == 1 && matrix.GetLength(1) == 1) {
                    // проверка для матрицы 1x1 - вычисление показательной функции числа
                    double value = matrix[0, 0]; // получение единственного элемента матрицы
                    // вычисление показательной функции числа по заданному основанию
                    double result = Math.Exp(value * Math.Log(baseDegree));
                    return new double[1, 1] { { result } }; // возвращение результата в виде матрицы 1x1
                }
                var mathNetMatrix = Matrix<double>.Build.DenseOfArray(matrix); // конвертация входного 2D массива в матрицу Math.NET
                var evd = mathNetMatrix.Evd(); // вычисление спектрального разложения
                var scaledMatrix = Math.Log(baseDegree) * mathNetMatrix; // вычисление ln(base) * A (подготовка к экспоненте)
                var scaledEvd = scaledMatrix.Evd(); // повторное спектральное разложение для scaledMatrix
                // вычисление экспоненты собственных значений
                var expEigenValues = Vector<double>.Build.Dense( // создание вектора Math.NET
                    scaledEvd.EigenValues.Count, // размер вектора = количеству собств. значений
                    i => Math.Exp(scaledEvd.EigenValues[i].Real)); // элементы: e^λᵢ (берется вещественная часть)
                // построение диагональной матрицы экспонент
                var diagMatrix = Matrix<double>.Build.DenseDiagonal( // создание диагональной матрицы
                    scaledEvd.EigenVectors.RowCount, // количество строк = размеру исходной матрицы
                    scaledEvd.EigenVectors.ColumnCount, // количество столбцов = размеру исходной матрицы
                    i => expEigenValues[i]); // заполнение диагонали: берется i-й элемент вектора expEigenValues
                // сборка результата по формуле матричной экспоненты base^A = V * e^D * V^(-1)
                var resultMatrix = scaledEvd.EigenVectors * diagMatrix * scaledEvd.EigenVectors.Inverse();
                return resultMatrix.ToArray(); ; // конвертация результата обратно в 2D массив
            }
            catch (Exception ex) {
                // сообщение об ошибке "Ошибка вычисления показателя матрицы:"
                MessageBox.Show($"Error calculating matrix exponent: {ex.Message}");
                // возвращение нулевой матрицы исходного размера
                return new double[matrix.GetLength(0), matrix.GetLength(1)];
            }
        }
        // Обработчик кнопки вычисления логарифма матрицы по основанию
        private void LogBaseMatrix_Click(object sender, RoutedEventArgs e) {
            if (!double.TryParse(txtLogarithm.Text, out double logBase) || logBase <= 0) { // парсинг основания логарифма с проверкой
                // сообщение об ошибке "Пожалуйста, введите корректное основание логарифма."
                MessageBox.Show("Please enter a valid logarithm base (positive number).");
                return;
            }
            var matrix = GetMatrixFromDataGrid(); // получение текущей матрицы
            if (matrix.GetLength(0) != matrix.GetLength(1)) { // проверка, что матрица квадратная
                // сообщение об ошибке "Для вычисления логарифма матрица должна быть квадратной."
                MessageBox.Show("Matrix must be square for logarithm calculation.");
                return;
            }
            try {
                var result = CalculateMatrixLogarithmBaseMathNet(matrix, logBase); // вычисление логарифма матрицы с помощью Math.NET
                DisplayMatrixInDataGrid(result); // отображение результата
            }
            catch (Exception ex) { // сообщение об ошибке "Ошибка при вычислении логарифма матрицы:"
                MessageBox.Show($"Error calculating matrix logarithm: {ex.Message}");
            }
        }
        // Вычисление логарифма матрицы по заданному основанию с использованием Math.NET
        private double[,] CalculateMatrixLogarithmBaseMathNet(double[,] matrix, double logBase) {
            /* порядок вычисления:
            A = V * D * V^(-1) - спектральное разложение матрицы
            D = diag(λ1, λ2, ..., λn) - диагональная матрица собственных значений
            V = [v1 | v2 | ... | vn] - матрица собственных векторов
            ln(A) = V * ln(D) * V^(-1), где ln(D) = diag(ln(λ1), ln(λ2), ..., ln(λn))
            logn(A) = ln(A) / ln(n) - переход к нужному основанию */
            try {
                if (matrix.GetLength(0) == 1 && matrix.GetLength(1) == 1) { // проверка для матрицы 1x1 - вычисление логарифма числа
                    double value = matrix[0, 0]; // получение единственного элемента матрицы
                    if (value <= 0) // проверка, что значение положительное
                        // сообщение об ошибке "Логарифм не определён для неположительных чисел."
                        throw new InvalidOperationException("Logarithm is undefined for non-positive numbers.");
                    double logValue = Math.Log(value, logBase); // вычисление логарифма числа по заданному основанию
                    return new double[1, 1] { { logValue } }; // возвращение результата в виде матрицы 1x1
                }
                var mathNetMatrix = Matrix<double>.Build.DenseOfArray(matrix); // конвертация входного 2D массива в матрицу Math.NET
                var evd = mathNetMatrix.Evd(); // вычисление спектрального разложения (EVD)
                foreach (var eigenValue in evd.EigenValues) {
                    if (eigenValue.Real <= 0) // проверка, что все собственные значения положительные
                        // сообщение об ошибке "Матрица имеет неположительные собственные значения - логарифм не определён."
                        throw new InvalidOperationException("Matrix has non-positive eigenvalues - logarithm is undefined.");
                }
                // логарифм вычисляется от собственных значений (только вещественная часть)
                var logEigenValues = Vector<double>.Build.Dense(
                    evd.EigenValues.Count, // размер вектора
                    i => Math.Log(evd.EigenValues[i].Real)); // функция преобразования
                // построение диагональной матрицы, где на диагонали находятся логарифмы собственных значений
                var diagMatrix = Matrix<double>.Build.DenseDiagonal(
                    evd.EigenVectors.RowCount, // количество строк
                    evd.EigenVectors.ColumnCount, // количество столбцов
                    i => logEigenValues[i]); // функция заполнения диагонали
                // восстановление матрицы обратно, вычисление матричного логарифма по формуле V * ln(D) * V^(-1)
                var lnMatrix = evd.EigenVectors * diagMatrix * evd.EigenVectors.Inverse();
                // переход к нужному основанию логарифма
                var resultMatrix = lnMatrix / Math.Log(logBase); // формула замены основания logn(A) = ln(A) / ln(n)
                return resultMatrix.ToArray(); // конвертация результата обратно в 2D массив
            }
            catch (Exception ex) {
                // сообщение об ошибке "Ошибка вычисления логарифма матрицы:"
                MessageBox.Show($"Error calculating matrix logarithm: {ex.Message}");
                // возвращение нулевой матрицы исходного размера
                return new double[matrix.GetLength(0), matrix.GetLength(1)];
            }
        }
        // Обработчик кнопки вычисления обратной матрицы
        private void Inverse_Click(object sender, RoutedEventArgs e) {
            var matrix = GetMatrixFromDataGrid(); // получение текущей матрицы
            if (matrix.GetLength(0) != matrix.GetLength(1)) { // проверка, что матрица квадратная
                // сообщение об ошибке "Для нахождения обратной матрицы исходная матрица должна быть квадратной."
                MessageBox.Show("Matrix must be square to find its inverse.");
                return;
            }
            double determinant = CalculateDeterminant(matrix); // вычисление определителя для проверки обратимости
            if (Math.Abs(determinant) < 1e-10) { // проверка, что матрица обратима (определитель не нулевой)
                // сообщение об ошибке "Матрица необратима – определитель равен нулю."
                MessageBox.Show("Matrix is not invertible (determinant is zero).");
                return;
            }
            double[,] inverseMatrix = CalculateInverseMatrix(matrix, determinant); // вычисление обратной матрицы
            DisplayMatrixInDataGrid(inverseMatrix); // отображение результата
        }
        // Вычисление обратной матрицы
        private double[,] CalculateInverseMatrix(double[,] matrix, double determinant) {
            /* обратная матрица A^(-1) вычисляется по формуле A^(-1) = (1 / det(A)) * adj(A), где:
                - det(A) — определитель матрицы A,
                - adj(A) — присоединённая матрица (матрица алгебраических дополнений, транспонированная).
            для матрицы 1x1:
                 A = [a] ⇒ A^(-1) = [1/a]
            для матрицы 2x2:
                [ a b ]^(-1)     1      [  d -b ]
                [ c d ]     = ------- * [ -c  a ]
                              ad - bc
            для матрицы 3x3 и более:
                a) вычисляется матрица миноров M:
                    M[i,j] = определитель подматрицы без i-й строки и j-го столбца
                b) матрица алгебраических дополнений C:
                    C[i,j] = (-1)^(i+j) * M[i,j]
                c) присоединённая матрица adj(A) = CT (транспонированная матрица алгебраических дополнений)
                d) обратная матрица A^(-1) = adj(A) / det(A) */
            int n = matrix.GetLength(0); // размер матрицы
            double[,] inverse = new double[n, n];
            if (n == 1) { // для матрицы 1x1
                inverse[0, 0] = 1.0 / matrix[0, 0];
                return inverse;
            }
            if (n == 2) { // формула для обратной матрицы 2x2
                // [ d -b ]
                // [ -c a ] / (ad - bc)
                inverse[0, 0] = matrix[1, 1] / determinant;
                inverse[0, 1] = -matrix[0, 1] / determinant;
                inverse[1, 0] = -matrix[1, 0] / determinant;
                inverse[1, 1] = matrix[0, 0] / determinant;
                return inverse;
            }
            // для матриц 3x3 и больше
            double[,] adjugate = CalculateAdjugateMatrix(matrix); // вычисление присоединённой (матрицы алгебраических дополнений)
            // деление каждого элемента присоединённой матрицы на определитель
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    inverse[i, j] = adjugate[i, j] / determinant;
                }
            }
            return inverse;
        }
        // Вычисление присоединенной матрицы (матрицы алгебраических дополнений)
        private double[,] CalculateAdjugateMatrix(double[,] matrix) {
            int n = matrix.GetLength(0); // размер матрицы
            double[,] adjugate = new double[n, n];
            // проход по всем элементам матрицы
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    double[,] minor = GetMinor(matrix, i, j); // получение минора для элемента (i,j) - матрица без i-й строки и j-го столбца
                    double minorDeterminant = CalculateDeterminant(minor); // вычисление определителя минора
                    // алгебраическое дополнение: (-1) ^ (i + j) * определитель минора
                    // присоединенная матрица – это транспонированная матрица алгебраических дополнений
                    // поэтому результат заносится в [j,i] вместо [i,j]
                    adjugate[j, i] = ((i + j) % 2 == 0 ? 1 : -1) * minorDeterminant;
                }
            }
            return adjugate;
        }
        // Обработчик кнопки вычисления натурального логарифма матрицы (ln(A))
        private void LogMatrix_Click(object sender, RoutedEventArgs e) {
            var matrix = GetMatrixFromDataGrid(); // получение текущей матрицы
            try {
                var result = CalculateMatrixLogarithm(matrix); // вычисление логарифма
                DisplayMatrixInDataGrid(result); // отображение результата
            }
            catch (InvalidOperationException ex) { // специальная обработка известных ошибок
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex) { // Общая обработка непредвиденных ошибок
                // сообщение об ошибке "Ошибка при вычислении логарифма:"
                MessageBox.Show($"Error calculating matrix logarithm: {ex.Message}", "Error",
                               MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        // Общий обработчик кнопок матричных функций (exp, sin, cos, tan, sinh, cosh, tanh)
        private void HandleMatrixFunction(object sender, RoutedEventArgs e, MatrixFunctionType functionType, string errorMessage) {
            var matrix = GetMatrixFromDataGrid(); // получение матрицы из DataGrid
            if (matrix.GetLength(0) != matrix.GetLength(1)) { // проверка, что матрица квадратная
                MessageBox.Show(errorMessage); // сообщение об ошибке, специфичное для каждой функции
                return;
            }
            var result = CalculateMatrixFunction(matrix, functionType); // вычисление с помощью функции CalculateMatrixFunction
            DisplayMatrixInDataGrid(result); // отображение результата в DataGrid
        }
        // Обработчик кнопки вычисления матричной экспоненты (e^A)
        private void ExpMatrix_Click(object sender, RoutedEventArgs e) {
            // сообщение об ошибке "Для возведения в степень матрица должна быть квадратной."
            HandleMatrixFunction(sender, e, MatrixFunctionType.Exp, "Matrix must be square for exponentiation.");
        }
        // Обработчик кнопки вычисления синуса матрицы (sin(A))
        private void SinMatrix_Click(object sender, RoutedEventArgs e) {
            // сообщение об ошибке "Для вычисления синуса матрица должна быть квадратной."
            HandleMatrixFunction(sender, e, MatrixFunctionType.Sin, "Matrix must be square for sine calculation.");
        }
        // Обработчик кнопки вычисления косинуса матрицы (cos(A))
        private void CosMatrix_Click(object sender, RoutedEventArgs e) {
            // сообщение об ошибке "Для вычисления косинуса матрица должна быть квадратной."
            HandleMatrixFunction(sender, e, MatrixFunctionType.Cos, "Matrix must be square for cosine calculation.");
        }
        // Обработчик кнопки вычисления тангенса матрицы (tan(A))
        private void TanMatrix_Click(object sender, RoutedEventArgs e) {
            // сообщение об ошибке "Для вычисления тангенса матрица должна быть квадратной."
            HandleMatrixFunction(sender, e, MatrixFunctionType.Tan, "Matrix must be square for tangent calculation.");
        }
        // Обработчик кнопки вычисления гиперболического синуса матрицы (sinh(A))
        private void SinhMatrix_Click(object sender, RoutedEventArgs e) {
            // сообщение об ошибке "Для вычисления гиперболического синуса матрица должна быть квадратной."
            HandleMatrixFunction(sender, e, MatrixFunctionType.Sinh, "Matrix must be square for hyperbolic sine calculation.");
        }
        // Обработчик кнопки вычисления гиперболического косинуса матрицы (cosh(A))
        private void CoshMatrix_Click(object sender, RoutedEventArgs e) {
            // сообщение об ошибке "Для вычисления гиперболического косинуса матрица должна быть квадратной."
            HandleMatrixFunction(sender, e, MatrixFunctionType.Cosh, "Matrix must be square for hyperbolic cosine calculation.");
        }
        // Обработчик кнопки вычисления гиперболического тангенса матрицы (tanh(A))
        private void TanhMatrix_Click(object sender, RoutedEventArgs e) {
            // сообщение об ошибке "Для вычисления гиперболического тангенса матрица должна быть квадратной."
            HandleMatrixFunction(sender, e, MatrixFunctionType.Tanh, "Matrix must be square for hyperbolic tangent calculation.");
        }
        // Перечисление типов матричных функций
        private enum MatrixFunctionType { Exp, Sin, Cos, Tan, Sinh, Cosh, Tanh }
        // Вычисление матричных функций через разложение в ряд Тейлора
        private double[,] CalculateMatrixFunction(double[,] matrix, MatrixFunctionType functionType, int terms = 20) {
            if (matrix.GetLength(0) == 1 && matrix.GetLength(1) == 1) { // проверка для матрицы 1x1 - вычисление функции от числа
                double value = matrix[0, 0];
                switch (functionType) {
                    case MatrixFunctionType.Exp:
                        return new double[1, 1] { { Math.Exp(value) } };
                    case MatrixFunctionType.Sin:
                        return new double[1, 1] { { Math.Sin(value) } };
                    case MatrixFunctionType.Cos:
                        return new double[1, 1] { { Math.Cos(value) } };
                    case MatrixFunctionType.Tan:
                        return new double[1, 1] { { Math.Tan(value) } };
                    case MatrixFunctionType.Sinh:
                        return new double[1, 1] { { Math.Sinh(value) } };
                    case MatrixFunctionType.Cosh:
                        return new double[1, 1] { { Math.Cosh(value) } };
                    case MatrixFunctionType.Tanh:
                        return new double[1, 1] { { Math.Tanh(value) } };
                    default:
                        throw new ArgumentException("Unknown matrix function type");
                }
            }
            // Вычисление функций через разложение в ряд Тейлора для матриц размером 2x2 и более
            // exp(A): I + A + A^2/2! + A^3/3! + ...
            // sin(A): A - A^3/3! + A^5/5! - ...
            // cos(A): I - A^2/2! + A^4/4! - ...
            // гиперболическиt функции: аналогично, но все заки "+"
            int n = matrix.GetLength(0); // размер матрицы
            // инициализация матриц
            double[,] result = new double[n, n];// результирующая матрица
            double[,] term = new double[n, n]; // текущее слагаемое ряда
            // инициализация в зависимости от типа функции
            switch (functionType) {  // инициализация в зависимости от типа функции
                case MatrixFunctionType.Exp:
                case MatrixFunctionType.Cos:
                case MatrixFunctionType.Cosh:
                    // старт с единичной матрицы для exp, cos, cosh
                    for (int i = 0; i < n; i++) term[i, i] = 1;
                    result = (double[,])term.Clone();
                    break;
                case MatrixFunctionType.Sin:
                case MatrixFunctionType.Tan:
                case MatrixFunctionType.Sinh:
                case MatrixFunctionType.Tanh:
                    // старт с оригинальной матрицы sin, tan, sinh, tanh
                    term = (double[,])matrix.Clone();
                    result = (double[,])term.Clone();
                    break;
            }
            // основной цикл вычисления ряда Тейлора
            for (int k = 1; k <= terms; k++) { // вычисление текущего слагаемого ряда
                double factor = 1; // знак слагаемого
                int power; // степень матрицы
                double denominator = 1; // знаменатель (факториал)
                // рассчет параметров на основе типа функции
                switch (functionType) {
                    case MatrixFunctionType.Exp: // для экспоненты: A^k / k!
                        power = k;
                        denominator = Factorial(power);
                        term = MultiplyMatrices(term, matrix);
                        term = ScalarMultiply(term, 1.0 / k);
                        break;
                    case MatrixFunctionType.Sin: // для синуса: (-1)^k * A^(2k + 1) / (2k + 1)!
                        factor = (k % 2 == 1) ? 1 : -1;
                        power = 2 * k - 1;
                        denominator = Factorial(power);
                        if (k > 1) {
                            term = MultiplyMatrices(term, matrix);
                            term = MultiplyMatrices(term, matrix);
                        }
                        break;
                    case MatrixFunctionType.Cos: // для косинуса: (-1)^k * A^(2k) / (2k)!
                        factor = (k % 2 == 1) ? -1 : 1;
                        power = 2 * k;
                        denominator = Factorial(power);
                        term = MultiplyMatrices(term, matrix);
                        term = MultiplyMatrices(term, matrix);
                        break;
                    case MatrixFunctionType.Sinh: // для гиперболического синуса: A^(2k+1) / (2k+1)!
                        factor = 1;
                        power = 2 * k - 1;
                        denominator = Factorial(power);
                        if (k > 1) {
                            term = MultiplyMatrices(term, matrix);
                            term = MultiplyMatrices(term, matrix);
                        }
                        break;
                    case MatrixFunctionType.Cosh: // для гиперболического косинуса: A^(2k) / (2k)!
                        factor = 1;
                        power = 2 * k;
                        denominator = Factorial(power);
                        term = MultiplyMatrices(term, matrix);
                        term = MultiplyMatrices(term, matrix);
                        break;
                }
                // добавление слагаемого к результату
                double[,] currentTerm = ScalarMultiply(term, factor / denominator);
                result = MatrixAddSubtract(result, currentTerm, true);
            }
            // дополнительные вычисления для тангенсов
            switch (functionType) {
                case MatrixFunctionType.Tan:
                    // tan(A) = sin(A) * cos(A)^-1
                    var cosA = CalculateMatrixFunction(matrix, MatrixFunctionType.Cos, terms);
                    var invCosA = CalculateInverseMatrix(cosA, CalculateDeterminant(cosA));
                    result = MultiplyMatrices(result, invCosA);
                    break;
                case MatrixFunctionType.Tanh:
                    // tanh(A) = sinh(A) * cosh(A)^-1
                    var coshA = CalculateMatrixFunction(matrix, MatrixFunctionType.Cosh, terms);
                    var invCoshA = CalculateInverseMatrix(coshA, CalculateDeterminant(coshA));
                    result = MultiplyMatrices(result, invCoshA);
                    break;
            }
            return result;
        }
        // Вычисление натурального логарифма матрицы через разложение в ряд
        private double[,] CalculateMatrixLogarithm(double[,] matrix, int terms = 100) {
            // определение размеров матрицы, количество
            int n = matrix.GetLength(0); // строк
            int m = matrix.GetLength(1);// столбцов
            if (n == 1 && m == 1) { // специальная обработка для матрицы 1x1 - ln числа
                double value = matrix[0, 0];
                if (value <= 0) { // сообщение об ошибке "Логарифм не определён для неположительных чисел."
                    throw new InvalidOperationException("Logarithm is undefined for non-positive numbers");
                }
                return new double[1, 1] { { Math.Log(value) } };
            }
            if (n != m) { // проверка, что матрица квадратная
                // сообщение об ошибке "Для вычисления логарифма матрица должна быть квадратной."
                throw new InvalidOperationException("Matrix must be square for logarithm calculation.");
            }
            // создание единичной матрицы
            double[,] I = new double[n, n];
            for (int i = 0; i < n; i++) I[i, i] = 1; // диагональные элементы = 1, остальные = 0
            // проверка на сходимость: норма (matrix - I) < 1
            double norm = 0;
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    // суммирование квадратов разностей
                    // для диагональных элементов вычитается 1, для недиагональных - просто значение элемента
                    norm += Math.Pow(matrix[i, j] - (i == j ? 1 : 0), 2);
                }
            }
            norm = Math.Sqrt(norm); // извлечение квадратного корня из суммы квадратов
            if (norm >= 1) { // если норма >= 1, ряд Тейлора может не сходиться
                // сообщение об ошибке "Для реализации логарифма норма матрицы (A-I) должна быть меньше 1."
                throw new InvalidOperationException("Matrix norm (A-I) must be less than 1 for this logarithm implementation.");
            }
            // вычисление логарифма через разложение в ряд Тейлора
            // ln(A) = (A-I) - (A-I)^2/2 + (A-I)^3/3 - ... + (-1)^(k+1)*(A-I)^k/k + ...
            double[,] result = new double[n, n];
            double[,] term = MatrixAddSubtract(matrix, I, false); // первое слагаемое ряда (A - I)
            for (int k = 1; k <= terms; k++) {
                double[,] currentTerm = ScalarMultiply(term, (k % 2 == 1 ? 1 : -1) / k);
                result = MatrixAddSubtract(result, currentTerm, true); // добавление текущего слагаемого ряда к результату
                term = MultiplyMatrices(term, MatrixAddSubtract(matrix, I, false)); // умножение term на (A -I) для следующего слагаемого
            }
            return result;
        }
        // ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ
        // Умножение матрицы на скаляр
        private double[,] ScalarMultiply(double[,] matrix, double scalar) {
            // определение размеров матрицы, количество
            int rows = matrix.GetLength(0); // строк
            int cols = matrix.GetLength(1); // столбцов
            double[,] result = new double[rows, cols]; // создание результирующей матрицы
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    result[i, j] = matrix[i, j] * scalar;
                }
            }
            return result;
        }
        // Выполнение операции над матрицами (сложение или вычитание)
        private double[,] MatrixAddSubtract(double[,] matrixA, double[,] matrixB, bool isAddition) {
            // получение размеров матриц (предполагается, что они одинаковые)
            int rows = matrixA.GetLength(0);
            int columns = matrixA.GetLength(1);
            var result = new double[rows, columns];
            // проход по всем элементам матриц
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < columns; j++) {
                    result[i, j] = isAddition
                        ? matrixA[i, j] + matrixB[i, j] // сложение
                        : matrixA[i, j] - matrixB[i, j]; // вычитание
                }
            }
            return result;
        }
        // Вычисление факториала (n!)
        private long Factorial(int n) {
            long result = 1;
            for (int i = 2; i <= n; i++) {
                result *= i;
            }
            return result;
        }
    }
}