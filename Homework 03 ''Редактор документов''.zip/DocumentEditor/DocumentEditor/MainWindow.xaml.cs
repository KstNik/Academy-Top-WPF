﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Documents;

namespace DocumentEditor {
    internal sealed partial class MainWindow : Window {
        public MainWindow() {
            InitializeComponent();
            StartTextBox.TextChanged += TextBox_TextChanged; // события
            EndTextBox.TextChanged += TextBox_TextChanged;
            BoldButton.Click += BoldButton_Click;
            ItalicButton.Click += ItalicButton_Click;
            UnderlineButton.Click += UnderlineButton_Click;
            ClearButton.Click += ClearButton_Click;
            FontSizeComboBox.SelectionChanged += FontSizeComboBox_SelectionChanged;
            ColorComboBox.SelectionChanged += ColorComboBox_SelectionChanged;
            DisableAllControls(); // изначально все элементы управления неактивны
        }
        // Метод для делегирования обработки событий изменения текста в полях ввода
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e) {
            UpdateControlsState();
        }
        // Метод для обновления состояния элементов управления
        private void UpdateControlsState() {
            // получение значений индексов из полей ввода
            int startIndex, endIndex;
            if (int.TryParse(StartTextBox.Text, out startIndex) && int.TryParse(EndTextBox.Text, out endIndex)) {
                // проверка корректности диапазона
                if (startIndex <= endIndex && startIndex >= 0 && endIndex < RichTextBox.Document.ContentStart.GetOffsetToPosition(RichTextBox.Document.ContentEnd))
                    EnableAllControls();
                else {
                    DisableAllControls();
                    return;
                }
            }
            else {
                DisableAllControls();
                return;
            }
        }
        // Метод для делегирования обработки событий нажатия на кнопку Bold
        private void BoldButton_Click(object sender, RoutedEventArgs e) {
            ApplyFormattingToSelection(TextElement.FontWeightProperty, FontWeights.Bold);
        }
        // Метод для делегирования обработки событий нажатия на кнопку Italic
        private void ItalicButton_Click(object sender, RoutedEventArgs e) {
            ApplyFormattingToSelection(TextElement.FontStyleProperty, FontStyles.Italic);
        }
        // Метод для делегирования обработки событий нажатия на кнопку Underline
        private void UnderlineButton_Click(object sender, RoutedEventArgs e) {
            ApplyUnderlineToSelection();
        }
        // Метод для делегирования обработки событий нажатия на кнопку Clear
        private void ClearButton_Click(object sender, RoutedEventArgs e) {
            ClearFormattingInSelection();
        }
        // Метод для делегирования обработки событий изменения размера шрифта
        private void FontSizeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e) {
            ApplyFormattingToSelection(TextElement.FontSizeProperty, Convert.ToDouble(((ComboBoxItem)FontSizeComboBox.SelectedItem).Content));
        }
        // Метод для делегирования обработки событий изменения цвета текста
        private void ColorComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e) {
            // получение StackPanel из выбранного элемента ComboBox
            StackPanel stackPanel = (StackPanel)((ComboBoxItem)ColorComboBox.SelectedItem).Content;
            // получение TextBlock, содержащий название цвета
            TextBlock colorTextBlock = (TextBlock)stackPanel.Children[1];
            // получение цвета из фонового свойства Border в StackPanel
            SolidColorBrush selectedColor = ((Border)stackPanel.Children[0]).Background as SolidColorBrush;
            // передача цвета в метод форматирования
            ApplyFormattingToSelection(TextElement.ForegroundProperty, selectedColor);
        }
        // Метод для получения TextRange по указанным индексам
        private TextRange GetTextRangeByIndices(int startIndex, int endIndex) {
            TextPointer startPointer = RichTextBox.Document.ContentStart;
            TextPointer endPointer = RichTextBox.Document.ContentStart;
            // перемещение курсора к началу и концу выделения
            for (int i = 0; i < startIndex; i++)
                startPointer = startPointer.GetNextInsertionPosition(LogicalDirection.Forward);
            for (int i = 0; i < endIndex; i++)
                endPointer = endPointer.GetNextInsertionPosition(LogicalDirection.Forward);
            return new TextRange(startPointer, endPointer);
        }
        // Метод для применения форматирования к выбранному диапазону текста
        private void ApplyFormattingToSelection(DependencyProperty formattingProperty, object value) {
            int startIndex = int.Parse(StartTextBox.Text);
            int endIndex = int.Parse(EndTextBox.Text);
            TextRange textRange = GetTextRangeByIndices(startIndex, endIndex);
            if (textRange != null) // применение форматирования к тексту
                textRange.ApplyPropertyValue(formattingProperty, value);
        }
        // Метод для применения подчёркивания к выбранному диапазону текста
        private void ApplyUnderlineToSelection() {
            int startIndex = int.Parse(StartTextBox.Text);
            int endIndex = int.Parse(EndTextBox.Text);
            TextRange textRange = GetTextRangeByIndices(startIndex, endIndex);
            if (textRange != null) // создание объекта подчёркивания и применение его к тексту
                textRange.ApplyPropertyValue(Inline.TextDecorationsProperty, TextDecorations.Underline);
         }
        // Метод для снятия форматирования с выбранного диапазона текста
        private void ClearFormattingInSelection() {
            int startIndex = int.Parse(StartTextBox.Text);
            int endIndex = int.Parse(EndTextBox.Text);
            TextRange textRange = GetTextRangeByIndices(startIndex, endIndex);
            if (textRange != null) // снятие всего форматирования с текста
                textRange.ClearAllProperties();
        }
        // Метод для управления доступностью элементов управления
        private void SetControlsEnabled(bool isEnabled) {
            BoldButton.IsEnabled = isEnabled;
            ItalicButton.IsEnabled = isEnabled;
            UnderlineButton.IsEnabled = isEnabled;
            ClearButton.IsEnabled = isEnabled;
            FontSizeComboBox.IsEnabled = isEnabled;
            ColorComboBox.IsEnabled = isEnabled;
        }
        // Метод для включения всех элементов управления
        private void EnableAllControls() {
            SetControlsEnabled(true);
        }
        // Метод для отключения всех элементов управления
        private void DisableAllControls() {
            SetControlsEnabled(false);
        }
    }
}

/*Задание. Необходимо разработать приложение, которое позволяло бы устанавливать разнообразные 
настройки форматирования заданным участкам текста.
В верхней части окна должна располагаться панель инструментов, содержащая элементы управления 
форматирования текста.
Для указания диапазона (фрагмента) текста необходимо использовать два поля для ввода текста, 
в которых будут задаваться индексы первого и последнего символа входящих в диапазон. Данные 
поля для ввода текста должны позволять вводить только положительные числа и ноль.
В случае указания некорректного диапазона (например, начальный индекс больше конечного или 
индекс за пределами текста), все остальные элементы управления на панели задач должны стать 
неактивными.
▪ Кнопка «Bold» должна делать текст в выбранном диапазоне жирным.
▪ Кнопка «Italic» должна делать текст в выбранном диапазоне курсивным.
▪ Кнопка «Underline» должна делать текст в выбранном диапазоне подчёркнутым.
▪ Кнопка «Clear» должна снимать все установленные настройки форматирования для текста в 
выбранном диапазоне (стиль текст, цвет и размер шрифта).
При выборе элемента из выпадающих списков, отвечающих за размер шрифта и его цвет, необходимо 
устанавливать соответствующее форматирование тексту в выбранном диапазоне.
Настройки форматирования могут накладываться друг на друга. Например, если в выбранном 
диапазоне содержится подчёркнутый текст и пользователь нажимает кнопку «Italic», то текст 
останется подчёркнутым, но при этом станет ещё и курсивным.*/