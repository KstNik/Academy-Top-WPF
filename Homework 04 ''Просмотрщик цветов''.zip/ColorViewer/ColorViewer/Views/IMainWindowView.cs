﻿namespace ColorViewer.Views
{
    internal interface IMainWindowView
    {
        void Show();
    }
}