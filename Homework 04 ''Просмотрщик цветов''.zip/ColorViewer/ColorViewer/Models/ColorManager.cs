﻿using System;
using System.Collections.Generic;

namespace ColorViewer.Models {
    internal sealed class ColorManager : IColorManager {
        private readonly ICollection<Color> colors = new List<Color>();
        public IEnumerable<Color> Colors => colors;
        public event EventHandler<ColorEventArgs> ColorAdded;
        public event EventHandler<ColorEventArgs> ColorRemoved;
        public void AddColor(Color color) {
            colors.Add(color);
            OnColorAdded(new ColorEventArgs(color));
        }
        public bool ContainsColor(Color color) {
            return colors.Contains(color);
        }
        public void RemoveColor(Color color) {
            if (colors.Remove(color))
                OnColorRemoved(new ColorEventArgs(color));
        }
        private void OnColorAdded(ColorEventArgs e) {
            ColorAdded?.Invoke(this, e);
        }
        private void OnColorRemoved(ColorEventArgs e) {
            ColorRemoved?.Invoke(this, e);
        }
    }
}