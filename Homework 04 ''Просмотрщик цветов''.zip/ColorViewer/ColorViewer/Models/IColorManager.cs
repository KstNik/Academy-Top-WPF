﻿using System;
using System.Collections.Generic;

namespace ColorViewer.Models {
    internal interface IColorManager {
        IEnumerable<Color> Colors { get; }
        event EventHandler<ColorEventArgs> ColorAdded;
        event EventHandler<ColorEventArgs> ColorRemoved;
        void AddColor(Color color);
        bool ContainsColor(Color color);
        void RemoveColor(Color color);
    }
}