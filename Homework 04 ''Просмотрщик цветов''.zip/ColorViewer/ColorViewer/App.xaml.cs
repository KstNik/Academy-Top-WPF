﻿using ColorViewer.Models;
using ColorViewer.Views;
using Ninject;
using Ninject.Extensions.Conventions;
using System.Windows;

namespace ColorViewer
{
    internal sealed partial class App : Application
    {
        private static IKernel CreateContainer()
        {
            var container = new StandardKernel();

            container.Bind(
                syntax => syntax
                    .FromThisAssembly()
                    .IncludingNonPublicTypes()
                    .SelectAllClasses()
                    .BindDefaultInterfaces()
                    .ConfigureFor<ColorManager>(configuration => configuration.InSingletonScope())
            );

            return container;
        }

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            IKernel container = CreateContainer();
            container
                .Get<IMainWindowView>()
                .Show();
        }
    }
}