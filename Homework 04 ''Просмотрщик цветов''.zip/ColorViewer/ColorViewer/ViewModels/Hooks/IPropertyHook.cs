﻿namespace ColorViewer.ViewModels.Hooks {
    internal interface IPropertyHook {
        void Execute(object instance, string propertyName);
    }
}