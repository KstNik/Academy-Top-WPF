﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace ColorViewer.ViewModels.Hooks {
    internal sealed class DependentPropertiesPropertyHook : IPropertyHook {
        private readonly Action<string> propertyCallback;
        private readonly Lazy<IReadOnlyDictionary<string, IEnumerable<PropertyInfo>>> propertyToDependentPropertiesMappings;
        public DependentPropertiesPropertyHook(object instance, Action<string> propertyCallback) {
            this.propertyCallback = propertyCallback;
            propertyToDependentPropertiesMappings = new Lazy<IReadOnlyDictionary<string, IEnumerable<PropertyInfo>>>(
                () => CreatePropertyToDependentPropertiesMappings(instance.GetType())
            );
        }
        private IReadOnlyDictionary<string, IEnumerable<PropertyInfo>> CreatePropertyToDependentPropertiesMappings(Type type) {
            var propertyToDependentPropertiesMappings = new Dictionary<string, ICollection<PropertyInfo>>();
            foreach (PropertyInfo property in type.GetProperties(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public)) {
                foreach (DependsUponPropertyAttribute attribute in property.GetCustomAttributes<DependsUponPropertyAttribute>()) {
                    if (!propertyToDependentPropertiesMappings.TryGetValue(attribute.PropertyName, out ICollection<PropertyInfo> dependentProperties)) {
                        dependentProperties = new List<PropertyInfo>();
                        propertyToDependentPropertiesMappings.Add(attribute.PropertyName, dependentProperties);
                    }
                    dependentProperties.Add(property);
                }
            }
            return propertyToDependentPropertiesMappings.ToDictionary(
                keyValuePair => keyValuePair.Key,
                keyValuePair => (IEnumerable<PropertyInfo>)keyValuePair.Value
            );
        }
        public void Execute(object instance, string propertyName) {
            if (propertyToDependentPropertiesMappings.Value.TryGetValue(propertyName, out IEnumerable<PropertyInfo> dependentProperties)) {
                foreach (PropertyInfo dependentProperty in dependentProperties)
                    propertyCallback(dependentProperty.Name);
            }
        }
    }
}