﻿using ColorViewer.Commands;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace ColorViewer.ViewModels.Hooks {
    internal sealed class CanExecuteCommandPropertyHook : IPropertyHook {
        private readonly Lazy<IReadOnlyDictionary<string, ICanExecuteChangedRaisable>> propertyToCommandMappings;
        public CanExecuteCommandPropertyHook(object instance) {
            propertyToCommandMappings = new Lazy<IReadOnlyDictionary<string, ICanExecuteChangedRaisable>>(
                () => CreatePropertyToCommandMappings(instance)
            );
        }
        private IReadOnlyDictionary<string, ICanExecuteChangedRaisable> CreatePropertyToCommandMappings(object instance) {
            var propertyToCommandMappings = new Dictionary<string, ICanExecuteChangedRaisable>();
            Type type = instance.GetType();
            foreach (PropertyInfo property in type.GetProperties(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public)) {
                foreach (CanExecutePropertyAttribute attribute in property.GetCustomAttributes<CanExecutePropertyAttribute>()) {
                    var command = (ICanExecuteChangedRaisable)property.GetValue(instance);
                    propertyToCommandMappings.Add(attribute.PropertyName, command);
                }
            }
            return propertyToCommandMappings;
        }
        public void Execute(object instance, string propertyName) {
            if (propertyToCommandMappings.Value.TryGetValue(propertyName, out ICanExecuteChangedRaisable command))
                command.RaiseCanExecuteChanged();
        }
    }
}