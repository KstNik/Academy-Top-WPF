﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace ColorViewer.ViewModels.Hooks {
    internal sealed class DependentMethodsPropertyHook : IPropertyHook {
        private readonly Lazy<IReadOnlyDictionary<string, IEnumerable<MethodInfo>>> propertyToDependentMethodsMappings;
        public DependentMethodsPropertyHook(object instance) {
            propertyToDependentMethodsMappings = new Lazy<IReadOnlyDictionary<string, IEnumerable<MethodInfo>>>(
                () => CreatePropertyToDependentMethodsMappings(instance.GetType())
            );
        }
        private IReadOnlyDictionary<string, IEnumerable<MethodInfo>> CreatePropertyToDependentMethodsMappings(Type type) {
            var propertyToDependentMethodsMappings = new Dictionary<string, ICollection<MethodInfo>>();
            foreach (MethodInfo method in type.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public)) {
                foreach (DependsUponPropertyAttribute attribute in method.GetCustomAttributes<DependsUponPropertyAttribute>()) {
                    if (!propertyToDependentMethodsMappings.TryGetValue(attribute.PropertyName, out ICollection<MethodInfo> dependentMethods)) {
                        dependentMethods = new List<MethodInfo>();
                        propertyToDependentMethodsMappings.Add(attribute.PropertyName, dependentMethods);
                    }
                    dependentMethods.Add(method);
                }
            }
            return propertyToDependentMethodsMappings.ToDictionary(
                keyValuePair => keyValuePair.Key,
                keyValuePair => (IEnumerable<MethodInfo>)keyValuePair.Value
            );
        }
        public void Execute(object instance, string propertyName) {
            if (propertyToDependentMethodsMappings.Value.TryGetValue(propertyName, out IEnumerable<MethodInfo> dependentMethods)) {
                foreach (MethodInfo method in dependentMethods)
                    method.Invoke(instance, parameters: null);
            }
        }
    }
}