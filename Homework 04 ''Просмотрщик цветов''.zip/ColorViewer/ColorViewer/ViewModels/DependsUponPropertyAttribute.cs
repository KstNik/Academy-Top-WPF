﻿using System;

namespace ColorViewer.ViewModels {
    [AttributeUsage(AttributeTargets.Method | AttributeTargets.Property, AllowMultiple = true)]
    internal sealed class DependsUponPropertyAttribute : Attribute {
        private readonly string propertyName;
        public DependsUponPropertyAttribute(string propertyName) {
            this.propertyName = propertyName;
        }
        public string PropertyName => propertyName;
    }
}