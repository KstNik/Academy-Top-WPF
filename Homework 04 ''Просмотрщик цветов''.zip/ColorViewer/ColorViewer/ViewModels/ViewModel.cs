﻿using ColorViewer.ViewModels.Hooks;
using System.Collections.Generic;
using System.ComponentModel;

namespace ColorViewer.ViewModels {
    internal abstract class ViewModel : Observable {
        private readonly IEnumerable<IPropertyHook> propertyChangedHooks;
        protected ViewModel() {
            propertyChangedHooks = new IPropertyHook[] {
                new CanExecuteCommandPropertyHook(this),
                new DependentMethodsPropertyHook(this),
                new DependentPropertiesPropertyHook(this, propertyName => OnPropertyChanged(new PropertyChangedEventArgs(propertyName)))
            };
        }
        protected override void OnPropertyChanged(PropertyChangedEventArgs e) {
            base.OnPropertyChanged(e);
            foreach (IPropertyHook propertyChangedHook in propertyChangedHooks)
                propertyChangedHook.Execute(this, e.PropertyName);
        }
    }
}