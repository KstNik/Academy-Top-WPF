﻿using ColorViewer.Commands;
using ColorViewer.Models;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Windows.Input;

namespace ColorViewer.ViewModels {
    internal sealed class MainWindowViewModel : ViewModel {
        private readonly ICommand addColorCommand;
        private readonly IColorManager colorManager;
        private readonly ObservableCollection<ColorViewModel> colors = new ObservableCollection<ColorViewModel>();
        private readonly ICommand loadedCommand;
        private readonly IViewModelFactory viewModelFactory;
        private bool canAddColor;
        private byte colorAlphaComponent = byte.MaxValue;
        private byte colorBlueComponent;
        private byte colorGreenComponent;
        private byte colorRedComponent;
        private string selectedColor;
        public MainWindowViewModel(IColorManager colorManager, IViewModelFactory viewModelFactory) {
            this.colorManager = colorManager;
            this.viewModelFactory = viewModelFactory;
            addColorCommand = new DelegateCommand(AddColor, () => CanAddColor);
            loadedCommand = new DelegateCommand(Load);
            colorManager.ColorAdded += ColorManager_ColorAdded;
            colorManager.ColorRemoved += ColorManager_ColorRemoved;
            colors.CollectionChanged += Colors_CollectionChanged;
        }
        [CanExecuteProperty(nameof(CanAddColor))]
        public ICommand AddColorCommand => addColorCommand;
        public bool CanAddColor {
            get => canAddColor;
            set => SetProperty(ref canAddColor, value);
        }
        public byte ColorAlphaComponent {
            get => colorAlphaComponent;
            set => SetProperty(ref colorAlphaComponent, value);
        }
        public byte ColorBlueComponent {
            get => colorBlueComponent;
            set => SetProperty(ref colorBlueComponent, value);
        }
        public byte ColorGreenComponent {
            get => colorGreenComponent;
            set => SetProperty(ref colorGreenComponent, value);
        }
        public byte ColorRedComponent {
            get => colorRedComponent;
            set => SetProperty(ref colorRedComponent, value);
        }
        public ICollection<ColorViewModel> Colors => colors;
        public ICommand LoadedCommand => loadedCommand;
        public string SelectedColor {
            get => selectedColor;
            set => SetProperty(ref selectedColor, value);
        }
        private void AddColor() {
            colorManager.AddColor(CreateColor());
        }
        private void ColorManager_ColorAdded(object sender, ColorEventArgs e) {
            ColorViewModel viewModel = viewModelFactory.CreateColorViewModel(e.Color);
            colors.Add(viewModel);
        }
        private void ColorManager_ColorRemoved(object sender, ColorEventArgs e) {
            ColorViewModel viewModel = colors.SingleOrDefault(color => color.Id.Equals(e.Color.Id));
            if (!(viewModel is null))
                colors.Remove(viewModel);
        }
        private void Colors_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e) {
            UpdateColorAdditionAbility();
        }
        private Color CreateColor() {
            return new Color(ColorAlphaComponent, ColorRedComponent, ColorGreenComponent, ColorBlueComponent);
        }
        private void Load() {
            UpdateColorAdditionAbility();
            UpdateSelectedColor();
        }
        [DependsUponProperty(nameof(ColorAlphaComponent))]
        [DependsUponProperty(nameof(ColorBlueComponent))]
        [DependsUponProperty(nameof(ColorGreenComponent))]
        [DependsUponProperty(nameof(ColorRedComponent))]
        private void UpdateColorAdditionAbility() {
            CanAddColor = !colorManager.ContainsColor(CreateColor());
        }
        [DependsUponProperty(nameof(ColorAlphaComponent))]
        [DependsUponProperty(nameof(ColorBlueComponent))]
        [DependsUponProperty(nameof(ColorGreenComponent))]
        [DependsUponProperty(nameof(ColorRedComponent))]
        private void UpdateSelectedColor() {
            SelectedColor = CreateColor().Name;
        }
    }
}