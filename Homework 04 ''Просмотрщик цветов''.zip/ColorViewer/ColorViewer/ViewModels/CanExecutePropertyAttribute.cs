﻿using System;

namespace ColorViewer.ViewModels {
    [AttributeUsage(AttributeTargets.Property)]
    internal sealed class CanExecutePropertyAttribute : Attribute {
        private readonly string propertyName;
        public CanExecutePropertyAttribute(string propertyName) {
            this.propertyName = propertyName;
        }
        public string PropertyName => propertyName;
    }
}