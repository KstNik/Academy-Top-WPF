﻿using ColorViewer.Models;

namespace ColorViewer.ViewModels {
    internal sealed class ViewModelFactory : IViewModelFactory {
        private readonly IColorManager colorManager;
        public ViewModelFactory(IColorManager colorManager) {
            this.colorManager = colorManager;
        }
        public ColorViewModel CreateColorViewModel(Color color) {
            return new ColorViewModel(color, colorManager);
        }
    }
}