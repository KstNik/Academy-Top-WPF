﻿using ColorViewer.Commands;
using ColorViewer.Models;
using System;
using System.Windows.Input;

namespace ColorViewer.ViewModels {
    internal sealed class ColorViewModel {
        private readonly IColorManager colorManager;
        private readonly ICommand deleteCommand;
        private readonly Color model;
        public ColorViewModel(Color model, IColorManager colorManager) {
            this.colorManager = colorManager;
            this.model = model;
            deleteCommand = new DelegateCommand(Delete);
        }
        public ICommand DeleteCommand => deleteCommand;
        public Guid Id => model.Id;
        public string Value => model.Name;
        private void Delete() {
            colorManager.RemoveColor(model);
        }
    }
}