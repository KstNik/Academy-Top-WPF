﻿using ColorViewer.Models;

namespace ColorViewer.ViewModels {
    internal interface IViewModelFactory {
        ColorViewModel CreateColorViewModel(Color color);
    }
}