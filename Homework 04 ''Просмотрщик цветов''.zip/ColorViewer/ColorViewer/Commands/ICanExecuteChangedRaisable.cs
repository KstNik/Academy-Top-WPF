﻿namespace ColorViewer.Commands {
    internal interface ICanExecuteChangedRaisable {
        void RaiseCanExecuteChanged();
    }
}